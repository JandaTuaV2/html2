<template>
  <div>
    <client-only>
      <big-calendar></big-calendar>
    </client-only>
  </div>
</template>
<script>
  export default {
    layout: 'DashboardLayout'
  }
</script>
