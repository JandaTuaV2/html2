import Chart from 'chart.js';
import { initGlobalOptions } from "@/components/argon-core/Charts/config";
export default {
  mounted() {
    initGlobalOptions();
  }
}
